// Event constructor
function Event(name, date, seats) {
    this.name = name;
    this.date = new Date(date);
    this.seats = seats;
} &
nbsp; &
nbsp;

// Sample events
const events = [
    new Event("Community Picnic", "2023-09-15", 50),
    new Event("Music Concert", "2023-10-01", 0),
    new Event("Art Workshop", "2023-11-05", 20)
]; &
nbsp; &
nbsp;

// Function to display events
function displayEvents() {
    const eventContainer = document.getElementById('eventContainer');
    const eventSelect = document.querySelector('select[name="event"]');
    eventContainer.innerHTML = ''; // Clear previous events
    eventSelect.innerHTML = '<option value="">Select an Event</option>'; // Reset select options
    &
    nbsp; &
    nbsp;

    events.forEach(event => {
        if (event.date > new Date() && event.seats > 0) {
            const eventCard = document.createElement('div');
            eventCard.className = 'event-card';
            eventCard.innerHTML = `
                <h3>${event.name}</h3>
                <p>Date: ${event.date.toDateString()}</p>
                <p>Seats Available: ${event.seats}</p>
                <button onclick="registerUser ('${event.name}')">Register</button>
            `;
            eventContainer.appendChild(eventCard); &
            nbsp; &
            nbsp;

            // Add event to select options
            const option = document.createElement('option');
            option.value = event.name;
            option.textContent = event.name;
            eventSelect.appendChild(option);
        }
    });
} &
nbsp; &
nbsp;

// Function to register user
function registerUser(eventName) {
    const event = events.find(e => e.name === eventName);
    if (event && event.seats > 0) {
        event.seats--;
        alert(`You have registered for ${event.name}.`);
        displayEvents(); // Refresh event display
    } else {
        alert('No seats available for this event.');
    }
} &
nbsp; &
nbsp;

// Form submission handling
document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
    const formData = new FormData(event.target);
    const name = formData.get('name');
    const email = formData.get('email');
    const selectedEvent = formData.get('event'); &
    nbsp; &
    nbsp;

    if (selectedEvent) {
        alert(`Thank you, ${name}! You have registered for ${selectedEvent}.`);
        event.target.reset(); // Reset form
    } else {
        alert('Please select an event.');
    }
}); &
nbsp; &
nbsp;

// Initial display of events
window.onload = function() {
    console.log("Welcome to the Community Portal");
    alert("Page fully loaded");
    displayEvents();
};