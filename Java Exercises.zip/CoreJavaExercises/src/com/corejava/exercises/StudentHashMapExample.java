package com.corejava.exercises;

import java.util.HashMap;
import java.util.Scanner;

public class StudentHashMapExample {

	public static void main(String[] args) {
		// Create a HashMap with Integer keys (student IDs) and String values (student names)
        HashMap<Integer, String> studentMap = new HashMap<>();

        Scanner scanner = new Scanner(System.in);
        String choice;

        // Loop to allow user to add entries
        do {
            System.out.print("Enter student ID (integer): ");
            int id = scanner.nextInt();
            scanner.nextLine();  // consume newline

            System.out.print("Enter student name: ");
            String name = scanner.nextLine();

            // Add entry to the HashMap
            studentMap.put(id, name);

            System.out.print("Do you want to add another entry? (yes/no): ");
            choice = scanner.nextLine().trim().toLowerCase();
        } while (choice.equals("yes"));

        // Retrieve a name based on entered ID
        System.out.print("Enter a student ID to retrieve the name: ");
        int searchId = scanner.nextInt();

        // Check if the ID exists and display the name
        if (studentMap.containsKey(searchId)) {
            System.out.println("Student name: " + studentMap.get(searchId));
        } else {
            System.out.println("No student found with ID " + searchId);
        }

        scanner.close();

	}

}
