package com.corejava.exercises;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentNameList {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        ArrayList<String> studentNames = new ArrayList<>();
        String name;
        String choice;

        System.out.println("Enter student names. Type 'no' when done.\n");

        // Loop to collect names
        do {
            System.out.print("Enter a student name: ");
            name = scanner.nextLine();
            studentNames.add(name);

            System.out.print("Do you want to add another name? (yes/no): ");
            choice = scanner.nextLine().toLowerCase();
        } while (choice.equals("yes"));

        // Display all entered names
        System.out.println("\nList of Student Names:");
        for (String student : studentNames) {
            System.out.println(student);
        }

        scanner.close();

	}

}
