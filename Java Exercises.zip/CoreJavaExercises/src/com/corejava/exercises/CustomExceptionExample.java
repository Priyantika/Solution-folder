package com.corejava.exercises;

import java.util.Scanner;

//Define custom exception
class InvalidAgeException extends Exception {
 public InvalidAgeException(String message) {
     super(message);
 }
}
public class CustomExceptionExample {
	 // Method to check age
    static void checkAge(int age) throws InvalidAgeException {
        if (age < 18) {
            throw new InvalidAgeException("Age must be 18 or older.");
        } else {
            System.out.println("Access granted. You are eligible.");
        }
}
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for age
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();

        try {
            checkAge(age);  // May throw InvalidAgeException
        } catch (InvalidAgeException e) {
            System.out.println("InvalidAgeException caught: " + e.getMessage());
        }

        scanner.close();
    }
}
