package com.corejava.exercises;

class Animal
{
	void makeSounds()
	{
		System.out.println("Animal makes sound");
	}
}

class Dog extends Animal
{

	@Override
	void makeSounds() 
	{
		System.out.println("Barks");
	}
	
}
public class InheritanceExample {

	public static void main(String[] args) {
		// Create an Animal object
        Animal genericAnimal = new Animal();
        genericAnimal.makeSounds();  // Output: Animal makes a sound

        // Create a Dog object
        Dog dog = new Dog();
        dog.makeSounds();  // Output: Bark

	}

}
