package com.corejava.exercises;

public class TypeCastingExample {

	public static void main(String[] args) {
		 // Declare a double variable
        double doubleValue = 9.75;

        // Cast double to int (explicit casting)
        int intFromDouble = (int) doubleValue;

        // Display the result
        System.out.println("Original double value: " + doubleValue);
        System.out.println("After casting to int: " + intFromDouble);

        // Declare an int variable
        int intValue = 15;

        // Cast int to double (implicit casting)
        double doubleFromInt = intValue;

        // Display the result
        System.out.println("Original int value: " + intValue);
        System.out.println("After casting to double: " + doubleFromInt);

	}

}
