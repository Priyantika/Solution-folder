package com.corejava.exercises;

import java.util.Scanner;

public class FactorialCalculator {

	public static void main(String[] args) {
		// Create Scanner object to read input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a non-negative integer
        System.out.print("Enter a non-negative integer: ");
        int number = scanner.nextInt();

        // Check if the number is valid
        if (number < 0) {
            System.out.println("Invalid input! Please enter a non-negative integer.");
        } else {
            long factorial = 1; // Use long for larger results

            // Calculate factorial using for loop
            for (int i = 1; i <= number; i++) {
                factorial *= i;
            }

            // Display the result
            System.out.println("Factorial of " + number + " is: " + factorial);
        }

        // Close the scanner
        scanner.close();
	}

}
