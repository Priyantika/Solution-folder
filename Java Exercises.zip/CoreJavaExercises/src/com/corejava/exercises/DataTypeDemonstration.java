package com.corejava.exercises;

public class DataTypeDemonstration {

	public static void main(String[] args) {
		 // Declare and assign values to variables of different primitive types
        int age = 20;
        float height = 5.9f;
        double weight = 65.75;
        char grade = 'A';
        boolean isPassed = true;

        // Display the values of each variable
        System.out.println("Integer (int) value: " + age);
        System.out.println("Float (float) value: " + height);
        System.out.println("Double (double) value: " + weight);
        System.out.println("Character (char) value: " + grade);
        System.out.println("Boolean (boolean) value: " + isPassed);

	}

}
