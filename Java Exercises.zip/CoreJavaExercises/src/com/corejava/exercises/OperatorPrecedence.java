package com.corejava.exercises;

public class OperatorPrecedence {

	public static void main(String[] args) {
		// Expression 1: Multiplication has higher precedence than addition
        int result1 = 10 + 5 * 2;
        System.out.println("Result of 10 + 5 * 2 = " + result1); // 10 + (5 * 2) = 20

        // Expression 2: Use of parentheses changes the order
        int result2 = (10 + 5) * 2;
        System.out.println("Result of (10 + 5) * 2 = " + result2); // (10 + 5) * 2 = 30

        // Expression 3: Mix of arithmetic and relational operators
        boolean result3 = 10 + 5 * 2 > 20;
        System.out.println("Result of 10 + 5 * 2 > 20 = " + result3); // 10 + 10 = 20; 20 > 20 = false

        // Expression 4: Logical operators with comparisons
        boolean result4 = (5 + 3) * 2 < 20 && 4 > 2;
        System.out.println("Result of (5 + 3) * 2 < 20 && 4 > 2 = " + result4); // 16 < 20 = true; 4 > 2 = true; true && true = true

	}

}
