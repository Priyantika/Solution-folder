package com.corejava.exercises;

public class PatternMatchingSwitch {

	public static void main(String[] args) {
		 String result = switch (obj) {
         case Integer i -> "This is an Integer with value " + i;
         case String s -> "This is a String with value \"" + s + "\"";
         case Double d -> "This is a Double with value " + d;
         case Float f -> "This is a Float with value " + f;
         case null -> "The object is null";
         default -> "Unknown type: " + obj.getClass().getName();
     };

     System.out.println(result);
 }

 public static void main(String[] args) {
     checkObjectType(42);
     checkObjectType("Hello, Java 21");
     checkObjectType(3.1415);
     checkObjectType(2.718f);
     checkObjectType(null);
     checkObjectType(new Object());

	}

}
